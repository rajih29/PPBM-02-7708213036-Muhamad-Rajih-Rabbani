package com.example.assement2

class ListData(
    var name: String,
    var time: String,
    var ingredients: Int,
    var desc: Int,
    var image: Int
)